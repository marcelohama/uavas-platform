Readme for DroidDraw-r1b21
(c) 2007-2012 Brendan Burns (brendan.d.burns@gmail.com)

DroidDraw is released under the GPLv2
See LICENSE.txt for more details

If you have problems launching droiddraw.exe (in particular on 64-bit machines), please just try double-clicking on droiddraw.jar.

Home:
http://www.droiddraw.org
http://www.droiddraw.org/tutorial.html

Source:
http://code.google.com/p/droiddraw

Bugs:
http://code.google.com/p/droiddraw/issues/list

Thanks!
